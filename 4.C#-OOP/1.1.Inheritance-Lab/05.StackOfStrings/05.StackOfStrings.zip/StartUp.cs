﻿namespace CustomStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var stack = new Stack<string>();
            var n = stack.Count;
        }
    }
}